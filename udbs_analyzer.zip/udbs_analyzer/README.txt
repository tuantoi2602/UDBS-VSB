Samotna aplikace UDBSAnalyzer.Desktop.exe na vyhodnocovani vasich SQL skritpu je v adresari UDBS_Analyzer. 
Nicmene pred spustenim teto aplikace je nutne mit instalovany potrebne knihovny z SQL Server Management Studia 2012 a také .NET framework 4.5.
Knihovny k SQL Serveru 2012 se nachazeji v adresari install; tzn. instalujte si je.
Po spusteni aplikace je nutne nastavit pripojeni k vlastni databazi.
K dispozici je take vzorovy projekt sample_sql_scripts.zip, po jehoz vlozeni by jste meli videt total score 15.

Hodne zdaru pri sestavovani pozadovanych dotazu. Prosim mejte na pameti, ze posledni slovo pri vyhodnocovani ma cvicici a tento nastroj je jen pomocnik. Snazte se tedy splnit pozadavky odpovidajicim zpusobem.
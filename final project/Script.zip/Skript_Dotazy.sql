


-- Part 1
/*1;1;1;
Find the most expensive shoe prices*/
select id from shoe
where price = (select max(price) from shoe)
/*1;2;1;
Find how many users in database*/
select count(*) from users
/*1;3;80;
Select shoe IDs ordered by the total amount of price*/
select id
from shoe
group by id
order by sum(price) asc

/*1;4;80;
Select shoe IDs ordered reverse by the total amount of price*/
select id
from shoe
group by id
order by sum(price) desc

-- Part 2
/*2;1;4;
Find a product name that's size is 10 and priced at $ 120 or $ 110 */
select name_of_product from shoe
where size_us = 10 and (price = 120 or price = 110 )
/*2;2;7;
Find brand name, except (nike, bitis, fila)*/
select brand_name from brand
where brand_name not in ('NIKE','BITIS','FILA')
/*2;3;5;
Find the names of shoes that start with AIR*/
select name_of_product from shoe
where name_of_product LIKE ('AIR%')
/*2;4;2;
Find the names of shoes that start with AIR and size is bigger than 10*/
select name_of_product from shoe
where size_us > 10 and name_of_product LIKE ('AIR%')

-- Part 3
/*3;1;1;
Select IDs of the seller and product with ID = 7*/
select user_id from shoe
where user_id not in (
    select id from users
    where id != 7
)
/*3;2;1;
Select IDs of the seller and product with ID = 7*/
select user_id from shoe
where not exists (
    select * from users
    where shoe.user_id = users.id and id != 7
)
/*3;3;1;
Select IDs of the seller and product with ID = 7*/
select user_id from shoe
where user_id != ALL (
    select id from users
    where id != 7
)
/*3;4;1;
Select IDs of the seller and product with ID = 7*/
select user_id from shoe
EXCEPT (
    select id from users
    where id != 7
)

-- Part 4

/*4;1;100;
Select the number of surnames for particular customers (their IDs)*/
select id, count(surname) as count from users
group by id
/*4;2;100;
Select the number of names for particular customers (their IDs)*/
select id, count(name) as count from users
group by id
/*4;3;13;
Select number of actors with the specified name and surname of each actors name and
surname. Name must be ordered by the number descendingly.*/
select name, surname, count(*) as count
from users
group by name,surname
order by name desc
/*4;4;13;
Select the ID of shoe where size of shoe is bigger 11*/
SELECT id
FROM shoe
GROUP BY id
HAVING MIN(size_us) > 11

-- Part 5
/*5;1;29;
Select all information about users including information of shoe*/
select distinct u1.id,login,name,surname,address_id,telephone,email,type
from users u1
join shoe s1 on s1.user_id = u1.id
/*5;2;29;
Select all information about users including information of shoe*/
select distinct u1.id,login,name,surname,address_id,telephone,email,type
from users u1
where u1.id in (
    select shoe.user_id
    from shoe
)
/*5;3;70;
Select all brand together with the list of shoe and count of brand is the same*/
select name_of_product, count(brand_name) as brand
from shoe
   left join brand on shoe.brand_id = brand.id
group by name_of_product
order by name_of_product asc
/*5;4;13;
Select all brand together with the list of shoe and start with keyword 'S' and 
count of brand is the same*/
select name_of_product, count(brand_name) as brand
from shoe
   left join brand on shoe.brand_id = brand.id
where shoe.name_of_product like 'S%'
group by name_of_product

-- Part 6
/*6;1;80;
Select the id and number of shoes the customer paid*/
select shoe.id, (
    select count(*) 
    from transactions
    where transactions.shoe_id = shoe.id
    )as brands 
from shoe
/*6;2;80;
Select the id and number of shoes the customer paid on 27.11*/
SELECT id, (
	SELECT COUNT(price)
	FROM transactions
	WHERE DAY(transaction_date) = 27 AND MONTH(transaction_date) = 11 AND transactions.shoe_id = shoe.id
	) AS '27.11'
FROM shoe

